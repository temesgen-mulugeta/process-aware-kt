Process-Aware KT submission materials

Read Process-Aware-KT-Final-Report.pdf (10 pages including references) first.
The final supporting diagnostics are in report/Diagnostic-Supplement.md.
Read report/ARTIFACTS.md for verification requirements and limitations.
Relative Markdown links to diagnostic files work within this package.

The immutable source/results archive is Process-Aware-KT-Artifacts-9a16cb6.tar.gz.
Extract it with:
  tar -xzf Process-Aware-KT-Artifacts-9a16cb6.tar.gz
Then, in process-aware-kt/ with the declared Python dependencies available:
  python scripts/verify_revision_artifacts.py
  python scripts/submission_checks.py

The archive contains the source/results at commit 9a16cb6, including the original
execution-source snapshot. Its documentation predates the final editorial pass;
the standalone supplement and guide alongside the PDF are the final versions.
Saved-score verification does not require the analyzer cache. Retraining requires
additional data, cache and encoder assets described in the artifact guide.
Dependencies were not tested in a newly installed clean environment in this pass.

Check the package's files with: shasum -a 256 -c SHA256SUMS
Submit the supporting files together with the paper. This package was prepared
locally; it has not been uploaded or submitted to an external service.
